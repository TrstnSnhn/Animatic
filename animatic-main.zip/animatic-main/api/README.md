# animatic

# py -3 -m venv .venv
# .venv\Scripts\activate

# run in cmd c:\Python312\python.exe -m pip install Flask Flask-Cors Pillow opencv-python-headless mediapipe numpy pygltflib trimesh

# run in terminal
# flask --app main run

# Run in F5
